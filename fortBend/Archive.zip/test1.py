"""
a script extracting data from fortbend agency
"""
import re
import pandas as pd
import pdfplumber

df = pd.DataFrame()
stored_data = {'Toll Agency':None,
                'Lp':None,
                 'Lp State':None,
                 'Trxn date & time':None,
                'Exit lane/Location':None,
                'Account #':None,
                 'Reference # or Invoice #':None,
                 'Violation #':None,
                 'Amount Due':None,
                  'Due Date':None,
                  'Pin #':None}

with pdfplumber.open("./scan_147mt_amazon_fbctra___(7)__august_8_(nko).pdf") as pdf:
    for x, text in enumerate(pdf.pages):
        page = pdf.pages[x]
        page_content = page.extract_text()
        # print(page_content)

        agency = re.findall(r'\w.(Fort Bend County Toll Road Authority)', page_content)
        license_plate = re.findall(r'S\d*\W*\d*\W\D\w*\W(\d*)\W\w*\W\w*\W*\D*\d*\W\d*\W\d*\W\d*\W\d*\W\d*\W\d*\W\W\d*\W\d*', page_content)
        state = re.findall(r'S\d*..\W\d*.(.\w*)\W\d*.\w*.\w*.\D*\d.\w*.\D*\d*\W\d*\W\d*\W\d*\W\d*\W\d*\W\d*\s\W\d\W\d*', page_content)
        trxn_date_time = re.findall(r'S\d*\W\d*.\w*\W\d*.\w*.\w*.\D*\d.\w*.\D*\d*\W(\d*\W\d*\W\d*\W\d*\W\d*\W\d*)\s\W\d\W\d*', page_content)
        exit_lane = re.findall(r'S\d*\W*\d*\W\D\w*\W\d*\W(\w*\W\w*\W*\D*\d*)\W\d*\W\d*\W\d*\W\d*\W\d*\W\d*\W\W\d*\W\d*', page_content)
        invoice = re.findall(r'(S\d*..\W\d*).\w*\W\d*.\w*.\w*.\D*\d.\w*.\D*\d*\W\d*\W\d*\W\d*\W\d*\W\d*\W\d*\s\W\d\W\d*', page_content)
        amount_due = re.findall(r'S\d*\W\d*.\w*\W\d*.\w*.\w*.\D*\d.\w*.\D*\d*\W\d*\W\d*\W\d*\W\d*\W\d*\W\d*\s(\W\d\W\d*)', page_content)
        due_date = re.findall(r'Date\WDue\W\W(\d*\W\d*\W\d*)', page_content)

        for x in range(len(state)):
            if agency:
                for agc in agency:
                    # print(agc)
                    stored_data['Toll Agency'] = agc
            if license_plate:
                for lp in license_plate:
                    # print(lp)
                    stored_data['Lp'] = lp
            if state:
                for st in state:
                    # print(st)
                    stored_data['Lp State'] = st
            if trxn_date_time:
                for trxn in trxn_date_time:
                    # print(trxn)
                    stored_data['Trxn date & time'] = trxn
            if exit_lane:
                for el in exit_lane:
                    # print(el)
                    stored_data['Exit lane/Location'] = el
            if invoice:
                for inv in invoice:
                    # print(inv)
                    stored_data['Reference # or Invoice #'] = inv
            if amount_due:
                for amt_d in amount_due:
                    # print(amt_d)
                    stored_data['Amount Due'] = amt_d
            if due_date:
                for dd in due_date:
                    # print(dd)
                    stored_data['Due Date'] = dd
            df = df.append(stored_data, ignore_index=True)
            print(df)
df.to_excel('fortbend147.xlsx', index=True)
