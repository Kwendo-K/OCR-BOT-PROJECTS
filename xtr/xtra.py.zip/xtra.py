"""
A python ocr bot extracting data from XTRA agency
"""
import re
import pandas as pd
import pdfplumber



stored_data = {
    'TOLL AGENCY':None,
    'LP':None,
    'TRXN DATE & TIME':None,
    'EXITLANE/LOCATION':None,
    'ACCOUNT #':None,
    'REFERENCE # OR INVOICE #':None,
    'VIOLATION':None,
    'AMOUNT DUE':None,
    'DUE DATE':None,
    'PIN #':None
}
# output_list = []

with pdfplumber.open('./SCAN_676_AMAZON_RENTAL_XTRA_TOLLS_SEPTEMBER_26_(SN).pdf') as pdf:
    output_list = []
    for i, text in enumerate(pdf.pages):
        df = pd.DataFrame()
        pages = pdf.pages[i]
        page_data = pages.extract_text()
        # print(page_data)

        invoice = re.findall(r'^Invoice\s*No\W*(\d*)\nInvoice\s*\Date\s*\d{2}\W*\d{2}\W*\d{4}', page_data)
        license_plate = re.findall(r'(\w{6})\s+\d+\s+\w+\s+\w+\W+\d+\W+', page_data)
        agency_exit_time = re.findall(r'Toll\s*\w*\s*\d{2}\W*\d{2}\W*\d{4}\s*\d{2}\W*\d{2}\W*\d{4}\W*(\d*\W*\d*)\W*\w*\n(\w*\W*\w*\W*\w*\W*\w*\W*\w*\s*\D*)loc(\D*)(\d*\D*\d*\D*\d*\D*\d*\D*\d*)', page_data)
        amount_due = re.findall(r'Toll\s*\w*\s*\d{2}\W*\d{2}\W*\d{4}\s*\d{2}\W*\d{2}\W*\d{4}\W*(\d*\W*\d*)', page_data)
        trxn_date_time = re.findall(r'\wn\W*(\d{4}\W*\d{2}\W*\d{2}\W*\d{2}\W*\d{2})', page_data)

        for a_mt in amount_due:
            amt = a_mt
        for l_p in license_plate:
            lp = l_p
        for al in agency_exit_time:
            agency = al[1]
            exit_lane = al[2]
        



        